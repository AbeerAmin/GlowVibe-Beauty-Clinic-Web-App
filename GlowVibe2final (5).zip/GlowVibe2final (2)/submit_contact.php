<?php
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

$to = "info@example.com";
$subject = "New Contact Request";
$headers = "From: " . $name . " <" . $email . ">";

if (mail($to, $subject, $message, $headers)) {
    echo "Your message has been sent successfully.";
} else {
    echo "There was an error sending your message.";
}
?>