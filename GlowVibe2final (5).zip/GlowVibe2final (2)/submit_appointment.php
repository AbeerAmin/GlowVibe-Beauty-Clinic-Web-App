<?php
$doctorName = $_POST['doctorName'];
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];
$patient_name = $_POST['patient_name'];
$patient_contact = $_POST['patient_contact'];

$to = "info@example.com";
$subject = "New Appointment Request";
$message = "Doctor: " . $doctorName . "\n";
$message .= "Appointment Date: " . $appointment_date . "\n";
$message .= "Appointment Time: " . $appointment_time . "\n";
$message .= "Patient Name: " . $patient_name . "\n";
$message .= "Patient Contact: " . $patient_contact . "\n";

$headers = "From: " . $patient_name . " <" . $patient_contact . ">";

if (mail($to, $subject, $message, $headers)) {
    echo "Your appointment request has been sent successfully.";
} else {
    echo "There was an error sending your appointment request.";
}
?>