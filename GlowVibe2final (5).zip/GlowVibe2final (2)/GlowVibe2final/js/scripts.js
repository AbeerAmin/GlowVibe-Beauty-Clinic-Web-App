// List of services and their corresponding pages
const services = [
  { id: 1, name: "Haircut", page: "haircut.html" },
  { id: 2, name: "Skin Care", page: "skincare.html" },
  { id: 3, name: "Makeup", page: "makeup.html" },
  { id: 4, name: "Hair Care", page: "haircare.html" },
];


function handleSearch() {
  const searchInput = document.getElementById("searchInput").value.toLowerCase();
  const selectedFilter = document.getElementById("serviceFilter").value;

  // Filter services based on search and filter criteria
  const filteredServices = services.filter((service) => {
    const matchesSearch = service.name.toLowerCase().includes(searchInput);
    const matchesFilter = selectedFilter ? service.name === selectedFilter : true;
    return matchesSearch && matchesFilter;
  });

  // Display or navigate to results
  const output = document.getElementById("output");
  output.innerHTML = "";

  if (filteredServices.length === 1) {
    // Navigate to the service page if exactly one match is found
    window.location.href = filteredServices[0].page;
  } else if (filteredServices.length > 1) {
    // Show a list of matching services
    output.innerHTML = `<h2>Matching Services:</h2>`;
    filteredServices.forEach((service) => {
      const serviceLink = document.createElement("a");
      serviceLink.href = service.page;
      serviceLink.textContent = service.name;
      serviceLink.style.display = "block";
      output.appendChild(serviceLink);
    });
  } else {
    // No matches found
    output.innerHTML = `<p>No matching services found. Try refining your search.</p>`;
  }
}
