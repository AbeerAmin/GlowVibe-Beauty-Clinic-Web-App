document.addEventListener("DOMContentLoaded", () => {
    const stripe = Stripe("YOUR_STRIPE_PUBLIC_KEY");
    const checkoutButton = document.getElementById("checkout-button");
    const cartItemsContainer = document.getElementById("cart-items");

    // Mock data for cart; replace this with data fetched dynamically if required.
    const cart = JSON.parse(document.getElementById("cart-data").value || "[]");

    // Display cart items
    cart.forEach(item => {
        const li = document.createElement("li");
        li.innerHTML = `<span>${item.product_name}</span> <span>$${item.product_price} x ${item.quantity}</span>`;
        cartItemsContainer.appendChild(li);
    });

    // Handle checkout button click
    checkoutButton.addEventListener("click", async () => {
        try {
            const response = await fetch("/create-checkout-session", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                }
            });

            if (!response.ok) {
                throw new Error("Failed to create checkout session");
            }

            const { url } = await response.json();
            window.location = url; // Redirect to Stripe Checkout
        } catch (error) {
            console.error("Error:", error);
            alert("An error occurred while processing the payment. Please try again.");
        }
    });
});
